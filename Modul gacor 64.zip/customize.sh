#!/system/bin/sh

set_perm_recursive $MODPATH 0 0 0755 0644
chmod 755 "$MODPATH/service.sh"
